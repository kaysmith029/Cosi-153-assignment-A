import * as React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

import WhyFoodLink from './components/WhyFoodLink';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';


export default function App() {
  return (
    <View style={styles.container}>

      <View style={{flex:1, flexDirection:'row',
              alignItems:'center',justifyContent:'space-around',backgroundColor:'#fdfff5',}}>
          <Text style={{fontSize:60,
             fontFamily:'Courier New' ,
             fontWeight: 'bold' }}>
              Welcome to Food Link.
          </Text>
      </View>

      <View style={{flex:1, flexDirection:'row',
              alignItems:'center',justifyContent:'space-around',backgroundColor:'#d0f0c0',}}>
          <Text style={{fontSize:20, fontFamily:'Courier New'}}>
              The app that realizes that you have more on your plate then making a grocery list. 

          <Button
          color='red' title= 'Get Started!'
          
          />

          <Button
          color='#00bfff' title= 'Why Food Link?'
          />
           
             
          </Text>
      </View>


      <Text style={styles.paragraph}>
      </Text>
            <Card>
        <AssetExample />
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'stretch',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#d0f0c0',
    alignItems: 'stretch',
    flexDirection:'column',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 30,
    fontFamily:'Courier New',
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
